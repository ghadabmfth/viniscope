import { FunctionComponent } from "react";

export type Row11Type = {
  className?: string;
};

const Row11: FunctionComponent<Row11Type> = ({ className = "" }) => {
  return (
    <div
      className={`self-stretch flex items-start justify-between gap-[1.25rem] max-w-full text-left text-[1rem] text-[#323232] font-['PP_Mori'] ${className}`}
    >
      <div className="h-[17.188rem] w-[14.188rem] flex flex-col items-start justify-between gap-[1.25rem]">
        <h2 className="m-0 self-stretch relative text-[1.875rem] tracking-[0.01em] leading-[1.875rem] font-light font-['PP_Eiko_Italic'] text-[#420001] [text-shadow:0.1px_0_0_#fcfaf9,_0_0.1px_0_#fcfaf9,_-0.1px_0_0_#fcfaf9,_0_-0.1px_0_#fcfaf9] mq450:text-[1.125rem] mq450:leading-[1.125rem]">
          Plan du site
        </h2>
        <div className="self-stretch relative tracking-[0.1em] uppercase font-extralight">
          Accueil
        </div>
        <div className="self-stretch relative tracking-[0.1em] uppercase font-extralight">
          A propos
        </div>
        <div className="self-stretch relative tracking-[0.1em] uppercase font-extralight">
          Nos ateliers
        </div>
        <div className="self-stretch relative tracking-[0.1em] uppercase font-extralight">
          Pour les entreprises
        </div>
        <div className="self-stretch relative tracking-[1.56px] uppercase font-extralight">
          Pour les particuliers
        </div>
      </div>
      <div className="h-[17.188rem] w-[17.313rem] flex flex-col items-start justify-between gap-[1.25rem]">
        <h2 className="m-0 self-stretch relative text-[1.875rem] tracking-[0.01em] leading-[1.875rem] font-light font-['PP_Eiko_Italic'] text-[#420001] [text-shadow:0.1px_0_0_#fcfaf9,_0_0.1px_0_#fcfaf9,_-0.1px_0_0_#fcfaf9,_0_-0.1px_0_#fcfaf9] mq450:text-[1.125rem] mq450:leading-[1.125rem]">
          Nos ateliers
        </h2>
        <div className="self-stretch relative tracking-[1.57px] uppercase font-extralight">
          Team building œnologique
        </div>
        <div className="self-stretch relative tracking-[0.1em] uppercase font-extralight">
          Dégustations thématiques
        </div>
        <div className="self-stretch relative tracking-[0.1em] uppercase font-extralight">
          Accords mets-vins
        </div>
        <div className="self-stretch relative tracking-[0.1em] uppercase font-extralight">
          Ateliers à domicile
        </div>
        <div className="self-stretch relative tracking-[0.1em] uppercase font-extralight">
          Vente de vins
        </div>
      </div>
      <div className="h-[11.25rem] w-[15.188rem] flex flex-col items-start justify-between gap-[1.25rem]">
        <h2 className="m-0 self-stretch relative text-[1.875rem] tracking-[0.01em] leading-[1.875rem] font-light font-['PP_Eiko_Italic'] text-[#420001] [text-shadow:0.1px_0_0_#fcfaf9,_0_0.1px_0_#fcfaf9,_-0.1px_0_0_#fcfaf9,_0_-0.1px_0_#fcfaf9] mq450:text-[1.125rem] mq450:leading-[1.125rem]">
          Nous Joindre
        </h2>
        <div className="self-stretch relative tracking-[0.1em] uppercase font-extralight">
          L’aventure viniscope
        </div>
        <div className="self-stretch relative tracking-[0.1em] uppercase font-extralight">
          Réserver un atelier
        </div>
        <div className="self-stretch relative tracking-[1.55px] uppercase font-extralight">
          Espace de recrutement
        </div>
      </div>
      <img
        className="h-[17.188rem] w-[24rem] object-cover max-w-full"
        loading="lazy"
        alt=""
        src="/column-4@2x.png"
      />
    </div>
  );
};

export default Row11;
