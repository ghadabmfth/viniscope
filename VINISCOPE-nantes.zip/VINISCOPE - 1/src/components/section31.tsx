import { FunctionComponent } from "react";

export type Section31Type = {
  className?: string;
};

const Section31: FunctionComponent<Section31Type> = ({ className = "" }) => {
  return (
    <section
      className={`self-stretch h-[28.813rem] flex flex-col items-center justify-between max-w-full text-center text-[2.5rem] text-[#420001] font-['PP_Mori'] ${className}`}
    >
      <div className="w-[81.25rem] h-[28.813rem] flex flex-col items-end gap-[3.031rem] max-w-full">
        <div className="flex items-start justify-end py-[0rem] pl-[19rem] pr-[18.937rem] mq450:pl-[1.25rem] mq450:pr-[1.25rem] mq450:box-border">
          <h2 className="m-0 h-[3.313rem] w-[43.313rem] relative text-[length:inherit] tracking-[0.01em] leading-[3.125rem] inline-block [text-shadow:0.1px_0_0_#420001,_0_0.1px_0_#420001,_-0.1px_0_0_#420001,_0_-0.1px_0_#420001] font-[inherit] mq450:text-[1.5rem] mq450:leading-[1.875rem]">
            <span className="font-extralight">{`Ce qu'ils ont `}</span>
            <span className="font-light font-['PP_Eiko_Italic']">pensé</span>
            <span className="font-extralight">{` de leur `}</span>
            <span className="font-light font-['PP_Eiko_Italic']">{`expérience `}</span>
            <span className="font-extralight">!</span>
          </h2>
        </div>
        <section className="w-[81.25rem] flex items-center justify-between gap-[1.25rem] max-w-full z-[1] text-left text-[1rem] text-[#420001] font-['PP_Mori']">
          <div className="flex flex-col items-start">
            <div className="w-[18.125rem] h-[16.313rem] flex flex-col items-start gap-[0.918rem]">
              <div className="flex items-start py-[0rem] pl-[0.062rem] pr-[0rem] text-[1.875rem]">
                <div className="flex flex-col items-start">
                  <div className="flex items-start gap-[0.456rem]">
                    <h2 className="m-0 h-[1.875rem] w-[15.5rem] relative text-[length:inherit] tracking-[0.01em] leading-[1.875rem] font-extralight font-[inherit] inline-block shrink-0 mq450:text-[1.125rem] mq450:leading-[1.125rem]">
                      Jeauneau Arnaud
                    </h2>
                    <img
                      className="h-[2.188rem] w-[2.106rem] relative object-cover shrink-0"
                      alt=""
                      src="/google-icon1@2x.png"
                    />
                  </div>
                  <h3 className="m-0 w-[6.25rem] h-[1.875rem] relative text-[1.25rem] tracking-[0.01em] leading-[1.875rem] font-light font-['PP_Eiko_Italic'] inline-block mt-[-0.313rem] mq450:text-[1rem] mq450:leading-[1.5rem]">
                     il y a 6 ans
                  </h3>
                </div>
              </div>
              <div className="flex items-start py-[0rem] px-[0.062rem]">
                <img
                  className="h-[1.25rem] w-[7.125rem] relative"
                  loading="lazy"
                  alt=""
                  src="/stars.svg"
                />
              </div>
              <div className="flex items-start py-[0rem] pl-[0.062rem] pr-[0rem] text-[#323232]">
                <div className="h-[7.5rem] w-[18.063rem] relative tracking-[0.05em] leading-[1.875rem] font-extralight inline-block shrink-0">
                  Florent est un professionnel qui a plus d'une corde à son arc,
                  il est l’écoute, travail avec passion et générosité...
                </div>
              </div>
              <div className="w-[5.813rem] h-[1.063rem] relative tracking-[0.1em] uppercase font-extralight inline-block">
                LIRE PLUS
              </div>
            </div>
          </div>
          <div className="flex flex-col items-start">
            <div className="w-[18.775rem] h-[16.313rem] flex flex-col items-start gap-[0.918rem]">
              <div className="flex flex-col items-start text-[1.875rem]">
                <div className="flex items-start gap-[1.131rem]">
                  <h2 className="m-0 h-[1.875rem] w-[15.456rem] relative text-[length:inherit] tracking-[0.01em] leading-[1.875rem] font-extralight font-[inherit] inline-block mq450:text-[1.125rem] mq450:leading-[1.125rem]">
                    Com l'Eléphant
                  </h2>
                  <img
                    className="h-[2.188rem] w-[2.188rem] relative object-cover"
                    alt=""
                    src="/Group-31@2x.png"
                  />
                </div>
                <h3 className="m-0 w-[7.294rem] h-[1.875rem] relative text-[1.25rem] tracking-[0.01em] leading-[1.875rem] font-light font-['PP_Eiko_Italic'] inline-block mt-[-0.313rem] mq450:text-[1rem] mq450:leading-[1.5rem]">
                   il y a 6 ans
                </h3>
              </div>
              <img
                className="w-[7.125rem] h-[1.25rem] relative"
                loading="lazy"
                alt=""
                src="/stars.svg"
              />
              <div className="w-[18.75rem] h-[7.5rem] relative tracking-[0.05em] leading-[1.875rem] font-extralight text-[#323232] inline-block">
                Offrez-vous une parenthèse conviviale avec Viniscope. Nos
                ateliers vous permettent de découvrir le vin autrement...
              </div>
              <div className="w-[6.706rem] h-[1.063rem] relative tracking-[0.1em] uppercase font-extralight inline-block">
                LIRE PLUS
              </div>
            </div>
          </div>
          <div className="flex flex-col items-start text-[1.875rem]">
            <div className="w-[18.75rem] h-[16.313rem] flex flex-col items-start gap-[2.812rem] mq450:gap-[1.375rem]">
              <div className="flex flex-col items-start gap-[0.906rem]">
                <div className="flex flex-col items-start py-[0rem] pl-[0rem] pr-[0.062rem]">
                  <div className="flex items-start gap-[1.856rem]">
                    <h2 className="m-0 h-[1.875rem] w-[14.625rem] relative text-[length:inherit] tracking-[0.01em] leading-[1.875rem] font-extralight font-[inherit] inline-block mq450:text-[1.125rem] mq450:leading-[1.125rem]">
                      Maafalda Batard
                    </h2>
                    <img
                      className="h-[2.188rem] w-[2.188rem] relative object-cover"
                      alt=""
                      src="/Group-31@2x.png"
                    />
                  </div>
                  <h3 className="m-0 w-[6.25rem] h-[1.875rem] relative text-[1.25rem] tracking-[0.01em] leading-[1.875rem] font-light font-['PP_Eiko_Italic'] inline-block mt-[-0.313rem] mq450:text-[1rem] mq450:leading-[1.5rem]">
                     il y a 6 ans
                  </h3>
                </div>
                <img
                  className="w-[7.394rem] h-[1.25rem] relative"
                  loading="lazy"
                  alt=""
                  src="/Group4.svg"
                />
                <div className="w-[18.75rem] h-[5.625rem] relative text-[1rem] tracking-[0.05em] leading-[1.875rem] font-extralight text-[#323232] inline-block">
                  Un passionné, passionnant ! Florent déniche, déguste et
                  propose des vins à découvrir absolument !<br />
                </div>
              </div>
              <div className="w-[5.813rem] h-[1.063rem] relative text-[1rem] tracking-[0.1em] uppercase font-extralight inline-block">
                LIRE PLUS
              </div>
            </div>
          </div>
          <div className="h-[16.313rem] w-[18.75rem] flex flex-col items-start text-[1.875rem]">
            <div className="self-stretch flex-1 flex flex-col items-start gap-[2.812rem] mq450:gap-[1.375rem]">
              <div className="flex flex-col items-start gap-[0.906rem]">
                <div className="flex flex-col items-start">
                  <div className="w-[18.75rem] flex items-start justify-between gap-[1.25rem]">
                    <h2 className="m-0 h-[1.875rem] w-[12.5rem] relative text-[length:inherit] tracking-[0.01em] leading-[1.875rem] font-extralight font-[inherit] inline-block mq450:text-[1.125rem] mq450:leading-[1.125rem]">
                      Julien Plantive
                    </h2>
                    <img
                      className="h-[2.188rem] w-[2.188rem] relative object-cover"
                      alt=""
                      src="/Group-31@2x.png"
                    />
                  </div>
                  <h3 className="m-0 w-[6.625rem] h-[1.875rem] relative text-[1.25rem] tracking-[0.01em] leading-[1.875rem] font-light font-['PP_Eiko_Italic'] inline-block mt-[-0.313rem] mq450:text-[1rem] mq450:leading-[1.5rem]">
                    il y a 9 mois
                  </h3>
                </div>
                <img
                  className="w-[7.394rem] h-[1.25rem] relative"
                  loading="lazy"
                  alt=""
                  src="/Group4.svg"
                />
                <div className="w-[18.75rem] h-[5.625rem] relative text-[1rem] tracking-[0.05em] leading-[1.875rem] font-extralight text-[#323232] inline-block">
                  Nous avons fait appel à Viniscope pour le vin de notre
                  mariage, et tout a été parfait du début à la fin.
                  <br />
                </div>
              </div>
              <div className="w-[5.813rem] h-[1.063rem] relative text-[1rem] tracking-[0.1em] uppercase font-extralight text-[#323232] inline-block">
                LIRE PLUS
              </div>
            </div>
          </div>
        </section>
        <div className="w-[81.25rem] flex items-start justify-center py-[0rem] px-[1.25rem] box-border max-w-full">
          <div className="w-[7.694rem] flex items-center justify-between gap-[1.25rem]">
            <img
              className="h-[3.125rem] w-[3.125rem] relative"
              loading="lazy"
              alt=""
              src="/Group-38.svg"
            />
            <img
              className="h-[3.125rem] w-[3.125rem] relative object-contain"
              loading="lazy"
              alt=""
              src
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Section31;
