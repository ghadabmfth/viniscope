import { FunctionComponent, useCallback } from "react";
import Hover from "./hover";

export type HeaderType = {
  className?: string;
};

const Header: FunctionComponent<HeaderType> = ({ className = "" }) => {
  const onProposTextClick = useCallback(() => {
    // Please sync "A propos" to the project
  }, []);

  const onNosAteliersTextClick = useCallback(() => {
    // Please sync "Atelier" to the project
  }, []);

  return (
    <header
      className={`w-[83.75rem] flex items-center justify-between gap-[1.25rem] text-left text-[1rem] text-[#323232] font-['PP_Mori'] lg:w-[35.313rem] lg:gap-[1.25rem] ${className}`}
    >
      <div className="w-[12.5rem] flex flex-col items-center">
        <div className="w-[12.5rem] h-[2.638rem] flex flex-col items-start gap-[0.437rem]">
          <img
            className="w-[12.5rem] h-[1.344rem] relative"
            loading="lazy"
            alt=""
            src="/Group-3.svg"
          />
          <div className="flex items-start py-[0rem] pl-[3.562rem] pr-[3.625rem]">
            <div className="flex items-end">
              <div className="flex flex-col items-start justify-end pt-[0rem] px-[0rem] pb-[0.187rem]">
                <div className="w-[0.188rem] h-[0.488rem] relative rounded-[1px] bg-[#420001]" />
              </div>
              <div className="flex flex-col items-start justify-end pt-[0rem] px-[0rem] pb-[0.243rem]">
                <div className="w-[1.238rem] h-[0.369rem] relative bg-[#420001]" />
              </div>
              <div className="flex flex-col items-start justify-end pt-[0rem] px-[0rem] pb-[0.187rem]">
                <div className="w-[1.363rem] h-[0.488rem] relative rounded-tl-[1px] rounded-tr-none rounded-br-none rounded-bl-[1px] bg-[#420001]" />
              </div>
              <div className="flex flex-col items-start justify-end pt-[0rem] px-[0rem] pb-[0.118rem]">
                <div className="w-[0.994rem] h-[0.613rem] relative rounded-tl-[1px] rounded-tr-none rounded-br-none rounded-bl-[1px] bg-[#420001]" />
              </div>
              <div className="h-[0.856rem] w-[1.481rem] relative">
                <div className="absolute top-[0rem] left-[0.988rem] rounded-[1px] bg-[#420001] w-[0.494rem] h-[0.856rem]" />
                <div className="absolute top-[0.063rem] left-[0rem] rounded-tl-[1px] rounded-tr-none rounded-br-none rounded-bl-[1px] bg-[#323232] w-[0.994rem] h-[0.731rem] z-[1]" />
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="w-[48.438rem] flex items-center justify-between py-[1.25rem] px-[0rem] box-border gap-[1.25rem] lg:hidden lg:gap-[1.25rem]">
        <div
          className="relative tracking-[0.1em] uppercase font-extralight cursor-pointer"
          onClick={onProposTextClick}
        >
          À propos
        </div>
        <div
          className="relative tracking-[0.1em] uppercase font-extralight cursor-pointer"
          onClick={onNosAteliersTextClick}
        >
          Nos ateliers
        </div>
        <div className="relative tracking-[0.1em] uppercase font-extralight">
          Pour les entreprises
        </div>
        <div className="relative tracking-[0.1em] uppercase font-extralight">
          Pour les particuliers
        </div>
      </div>
      <Hover property1="Default" />
    </header>
  );
};

export default Header;
