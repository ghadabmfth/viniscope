import { FunctionComponent, type CSSProperties } from "react";

export type HoverType = {
  className?: string;

  /** Variant props */
  property1?: CSSProperties["property1"];
};

const Hover: FunctionComponent<HoverType> = ({
  className = "",
  property1 = "Default",
}) => {
  return (
    <button
      className={`cursor-pointer [border:none] p-0 bg-[transparent] h-[4.375rem] w-[12.5rem] overflow-hidden shrink-0 flex items-start ${className}`}
    >
      <div className="h-[4.375rem] w-[12.5rem] flex items-start pt-[1.625rem] pb-[1.687rem] pl-[2.312rem] pr-[2.187rem] box-border relative isolate">
        <div className="h-full w-full absolute !!m-[0 important] top-[0rem] right-[0rem] bottom-[0rem] left-[0rem] rounded-[80px] bg-[#420001] z-[0] shrink-0" />
        <div className="h-[1.063rem] w-[8rem] relative text-[1rem] tracking-[0.1em] uppercase font-['PP_Mori'] text-[#fff] text-left inline-block z-[1] shrink-0">
          réSERVATION
        </div>
      </div>
    </button>
  );
};

export default Hover;
