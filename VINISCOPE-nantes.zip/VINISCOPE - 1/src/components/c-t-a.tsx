import { FunctionComponent } from "react";

export type CTAType = {
  className?: string;
};

const CTA: FunctionComponent<CTAType> = ({ className = "" }) => {
  return (
    <section
      className={`w-[83.75rem] flex items-center justify-between gap-[1.25rem] text-left text-[2.5rem] text-[#420001] font-['PP_Mori'] ${className}`}
    >
      <div className="flex items-center justify-center">
        <h1 className="m-0 w-[34.813rem] relative text-[length:inherit] tracking-[0.01em] inline-block shrink-0 [text-shadow:0.1px_0_0_#420001,_0_0.1px_0_#420001,_-0.1px_0_0_#420001,_0_-0.1px_0_#420001] font-[inherit] mq450:text-[1.5rem]">
          <span className="font-extralight">Partez à la</span>
          <span className="font-light font-['PP_Eiko_Italic']">{` découverte `}</span>
          <span className="font-extralight">{`des `}</span>
          <span className="font-light font-['PP_Eiko_Italic']">
            vignobles français ...
          </span>
        </h1>
      </div>
      <div className="flex items-center justify-center py-[1.25rem] px-[0rem] text-[1rem] text-[#323232]">
        <div className="w-[29.188rem] relative tracking-[0.05em] leading-[1.875rem] font-extralight inline-block shrink-0">
          Recevez notre sélection exclusive de vins, des conseils de dégustation
          et des bons plans réservés à nos abonnés.
        </div>
      </div>
      <button className="cursor-pointer [border:none] p-0 bg-[transparent] h-[4.375rem] w-[12.563rem] flex flex-col items-center">
        <div className="w-full h-[4.375rem] rounded-[80px] bg-[#420001] flex items-start pt-[1.643rem] pb-[1.668rem] pl-[2.25rem] pr-[2.062rem] box-border max-w-full">
          <div className="h-[4.375rem] w-[12.563rem] relative rounded-[80px] bg-[#420001] hidden shrink-0" />
          <div className="h-[1.063rem] w-[8.188rem] relative text-[1rem] tracking-[0.1em] uppercase font-['PP_Mori'] text-[#fff] text-left inline-block shrink-0 z-[1]">
            Je découvre
          </div>
        </div>
      </button>
    </section>
  );
};

export default CTA;
