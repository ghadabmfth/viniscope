import { FunctionComponent, useMemo, type CSSProperties } from "react";

export type FrameComponentType = {
  className?: string;
  propos?: string;
  image3?: string;

  /** Style props */
  proposWidth?: CSSProperties["width"];
  proposDisplay?: CSSProperties["display"];
  proposAlignSelf?: CSSProperties["alignSelf"];
};

const FrameComponent: FunctionComponent<FrameComponentType> = ({
  className = "",
  propos,
  proposWidth,
  proposDisplay,
  proposAlignSelf,
  image3,
}) => {
  const proposStyle: CSSProperties = useMemo(() => {
    return {
      width: proposWidth,
      display: proposDisplay,
      alignSelf: proposAlignSelf,
    };
  }, [proposWidth, proposDisplay, proposAlignSelf]);

  return (
    <section
      className={`h-[27.5rem] w-[20.938rem] flex flex-col items-center justify-between py-[1.25rem] px-[0rem] box-border gap-[1.25rem] max-w-full text-left text-[1.875rem] text-[#fcfaf9] font-['PP_Mori'] ${className}`}
    >
      <div className="self-stretch h-[9.375rem] flex flex-col items-start">
        <h2 className="m-0 relative text-[length:inherit] tracking-[0.01em] leading-[3.125rem] [text-shadow:0.1px_0_0_#420001,_0_0.1px_0_#420001,_-0.1px_0_0_#420001,_0_-0.1px_0_#420001] font-[inherit] mq450:text-[1.125rem] mq450:leading-[1.875rem]">
          <span className="font-extralight">{`Accords `}</span>
          <span className="font-light font-['PP_Eiko_Italic']">{`mets & vins`}</span>
        </h2>
        <div
          className="w-[20.938rem] relative text-[1rem] tracking-[0.05em] leading-[1.875rem] font-extralight inline-block"
          style={proposStyle}
        >
          {propos}
        </div>
      </div>
      <img
        className="w-[20.938rem] h-[13.875rem] relative rounded-[20px] object-cover"
        loading="lazy"
        alt=""
        src={image3}
      />
    </section>
  );
};

export default FrameComponent;
