import { FunctionComponent } from "react";

export type Row21Type = {
  className?: string;
};

const Row21: FunctionComponent<Row21Type> = ({ className = "" }) => {
  return (
    <div
      className={`self-stretch flex items-center justify-between gap-[1.25rem] max-w-full text-left text-[1rem] text-[#420001] font-['PP_Mori'] ${className}`}
    >
      <div className="w-[14.375rem] flex flex-col items-center justify-center gap-[0.5rem]">
        <img
          className="w-[14.375rem] h-[1.569rem] relative"
          loading="lazy"
          alt=""
          src="/Group-32.svg"
        />
        <div className="w-[6.063rem] h-[1rem] relative">
          <div className="absolute top-[0.213rem] left-[0rem] rounded-[1px] bg-[#420001] w-[0.213rem] h-[0.569rem]" />
          <div className="absolute top-[0rem] left-[5.494rem] rounded-[1px] bg-[#420001] w-[0.569rem] h-[1rem]" />
          <div className="absolute top-[0.281rem] left-[0.213rem] bg-[#420001] w-[1.425rem] h-[0.425rem]" />
          <div className="absolute top-[0.213rem] left-[1.644rem] rounded-tl-[1px] rounded-tr-none rounded-br-none rounded-bl-[1px] bg-[#420001] w-[1.569rem] h-[0.569rem]" />
          <div className="absolute top-[0.138rem] left-[3.213rem] rounded-tl-[1px] rounded-tr-none rounded-br-none rounded-bl-[1px] bg-[#420001] w-[1.144rem] h-[0.713rem]" />
          <div className="absolute top-[0.069rem] left-[4.35rem] rounded-tl-[1px] rounded-tr-none rounded-br-none rounded-bl-[1px] bg-[#323232] w-[1.144rem] h-[0.856rem] z-[1]" />
        </div>
      </div>
      <div className="flex items-center gap-[0.625rem]">
        <div className="h-[3.125rem] w-[3.125rem] rounded-[25px] border-[#420001] border-solid border-[1px] box-border flex items-center justify-between py-[0.812rem] px-[0.937rem]">
          <img
            className="w-[0.65rem] relative max-h-full"
            loading="lazy"
            alt=""
            src="/Group.svg"
          />
        </div>
        <div className="h-[3.125rem] w-[3.125rem] rounded-[25px] border-[#420001] border-solid border-[1px] box-border flex items-center justify-between py-[0.812rem] px-[0.875rem]">
          <img
            className="w-[1.25rem] relative max-h-full"
            alt=""
            src="/Group1.svg"
          />
        </div>
        <div className="h-[3.125rem] w-[3.125rem] rounded-[25px] border-[#420001] border-solid border-[1px] box-border flex items-center justify-between py-[0.812rem] px-[0.875rem]">
          <img
            className="w-[1.25rem] relative max-h-full"
            alt=""
            src="/Group3.svg"
          />
        </div>
        <div className="h-[3.125rem] w-[3.125rem] rounded-[25px] border-[#420001] border-solid border-[1px] box-border flex items-center justify-between p-[0.937rem]">
          <img
            className="w-[1.406rem] relative max-h-full shrink-0"
            loading="lazy"
            alt=""
            src="/Group2.svg"
          />
        </div>
      </div>
      <div className="w-[46rem] flex items-center justify-between gap-[1.125rem] max-w-full">
        <div className="h-[4.375rem] w-[30.063rem] rounded-[80px] border-[#420001] border-solid border-[1px] box-border flex flex-col items-center justify-between py-[1.5rem] px-[0.937rem]">
          <div className="w-[27.238rem] h-[1.125rem] flex items-start gap-[0.668rem]">
            <img
              className="h-[1.125rem] w-[0.944rem] relative shrink-0"
              loading="lazy"
              alt=""
              src="/icon-pin.svg"
            />
            <div className="flex flex-col items-start pt-[0.062rem] px-[0rem] pb-[0rem] shrink-0">
              <div className="w-[25.75rem] h-[1.063rem] relative tracking-[0.1em] uppercase inline-block">
                31 RUE DE LA LOIRE, Le Loroux Bottereau
              </div>
            </div>
          </div>
        </div>
        <button className="cursor-pointer border-[#420001] border-solid border-[1px] py-[1.437rem] px-[1.5rem] bg-[transparent] rounded-[80px] flex flex-col items-center">
          <div className="w-[11.688rem] h-[1.25rem] flex items-start gap-[0.312rem]">
            <img
              className="w-[1.25rem] relative max-h-full shrink-0"
              alt=""
              src="/Vector.svg"
            />
            <div className="flex flex-col items-start pt-[0.125rem] px-[0rem] pb-[0rem] shrink-0">
              <div className="w-[10.25rem] h-[1.063rem] relative text-[1rem] tracking-[0.1em] uppercase font-['PP_Mori'] text-[#420001] text-left inline-block">
                +33 6 30 56 56 98
              </div>
            </div>
          </div>
        </button>
      </div>
    </div>
  );
};

export default Row21;
