import { FunctionComponent } from "react";

export type Section11Type = {
  className?: string;
};

const Section11: FunctionComponent<Section11Type> = ({ className = "" }) => {
  return (
    <section
      className={`self-stretch flex flex-col items-center relative isolate gap-[2.812rem] max-w-full text-center text-[2.5rem] text-[#420001] font-['PP_Mori'] ${className}`}
    >
      <div className="h-[10rem] flex flex-col items-center justify-between gap-[1.062rem] z-[0]">
        <h1 className="m-0 w-[73.056rem] relative text-[length:inherit] tracking-[0.01em] leading-[3.125rem] inline-block [text-shadow:0.1px_0_0_#420001,_0_0.1px_0_#420001,_-0.1px_0_0_#420001,_0_-0.1px_0_#420001] font-[inherit] mq450:text-[1.5rem] mq450:leading-[1.875rem]">
          <span className="font-extralight">Une expérience</span>
          <span className="font-light font-['PP_Eiko_Italic']">{` œnologique `}</span>
          <span className="font-extralight">{`accessible à `}</span>
          <span className="font-light font-['PP_Eiko_Italic']">tous</span>
          <span className="font-extralight"> ...</span>
        </h1>
        <div className="w-[75rem] relative text-[1rem] tracking-[0.05em] leading-[1.875rem] font-extralight text-[#323232] inline-block">
          Chez Viniscope, nous vous proposons des ateliers de dégustation de vin
          pensés pour tous les niveaux. Apprenez à reconnaître les arômes,
          comprendre les cépages et affiner votre palais dans une ambiance
          conviviale et pédagogique. Nos ateliers sont animés par des passionnés
          pour vous offrir une expérience authentique et enrichissante.
        </div>
      </div>
      <section className="flex items-end gap-[4.75rem] max-w-full z-[1] text-center text-[1.875rem] text-[#420001] font-['PP_Mori'] mq450:gap-[1.188rem]">
        <div className="w-[23.438rem] flex flex-col items-center justify-center gap-[0.625rem] max-w-full">
          <img
            className="w-[7.319rem] relative max-h-full"
            loading="lazy"
            alt=""
            src="/Group-4.svg"
          />
          <h2 className="m-0 self-stretch relative text-[length:inherit] tracking-[0.01em] leading-[3.125rem] [text-shadow:0.1px_0_0_#420001,_0_0.1px_0_#420001,_-0.1px_0_0_#420001,_0_-0.1px_0_#420001] font-[inherit] mq450:text-[1.125rem] mq450:leading-[1.875rem]">
            <span className="font-extralight">{`Sélection de `}</span>
            <span className="font-light font-['PP_Eiko_Italic']">
              vignerons
            </span>
          </h2>
          <div className="self-stretch relative text-[1rem] tracking-[0.05em] leading-[1.875rem] font-extralight text-[#323232]">
            Beaucoup de temps passé dans les vignobles de France afin de
            proposer une sélection la plus pointue possible avec des vins
            produits par des ARTISANS-VIGNERONS sur des domaines à taille
            humaine.
          </div>
        </div>
        <div className="w-[23.438rem] flex flex-col items-center gap-[0.562rem] max-w-full">
          <img
            className="w-[6.556rem] relative max-h-full"
            loading="lazy"
            alt=""
            src="/Group-5.svg"
          />
          <h2 className="m-0 self-stretch relative text-[length:inherit] tracking-[0.01em] leading-[3.125rem] [text-shadow:0.1px_0_0_#420001,_0_0.1px_0_#420001,_-0.1px_0_0_#420001,_0_-0.1px_0_#420001] font-[inherit] mq450:text-[1.125rem] mq450:leading-[1.875rem]">
            <span className="font-extralight"> Vins</span>
            <span className="font-semibold">{` `}</span>
            <span className="font-light font-['PP_Eiko_Italic']">inédits</span>
          </h2>
          <div className="self-stretch relative text-[1rem] tracking-[0.05em] leading-[1.875rem] font-extralight text-[#323232]">
            Un goût particulier pour la découverte et l'envie de partager afin
            d'offrir à chacun la possibilité de déguster et se de procurer des
            VINS ATYPIQUES ou des appellations plus connues de grande qualité.
          </div>
        </div>
        <div className="h-[22.438rem] w-[23.438rem] flex flex-col items-center justify-between gap-[1.062rem] max-w-full">
          <img
            className="w-[8.137rem] h-[7.813rem] relative"
            loading="lazy"
            alt=""
            src="/Group-6.svg"
          />
          <h2 className="m-0 self-stretch relative text-[length:inherit] tracking-[0.01em] leading-[3.125rem] [text-shadow:0.1px_0_0_#420001,_0_0.1px_0_#420001,_-0.1px_0_0_#420001,_0_-0.1px_0_#420001] font-[inherit] mq450:text-[1.125rem] mq450:leading-[1.875rem]">
            <span className="font-extralight">{`Approche `}</span>
            <span className="font-light font-['PP_Eiko_Italic']">
              éco-responsable
            </span>
          </h2>
          <div className="self-stretch relative text-[1rem] tracking-[0.05em] leading-[1.875rem] font-extralight text-[#323232]">
            Une proximité depuis toujours avec la nature qui amène une sélection
            vers des vignobles TRAVAILLANT LA VIGNE AVEC RESPECT, en Agriculture
            Biologique ou en Biodynamie notamment.
          </div>
        </div>
      </section>
      <button className="cursor-pointer [border:none] py-[1.562rem] px-[2.5rem] bg-[#420001] w-[24.063rem] h-[4.375rem] rounded-[80px] flex items-center justify-between box-border z-[2] hover:bg-[#753333] hover:gap-2.5">
        <div className="relative text-[1rem] tracking-[0.1em] uppercase font-['PP_Mori'] text-[#fff] text-left">{`Apprendre à nous connaitre `}</div>
      </button>
      <img
        className="w-[48.69%] h-[5.82%] absolute !!m-[0 important] top-[42.46%] right-[25.66%] bottom-[51.72%] left-[25.65%] max-w-full overflow-hidden max-h-full z-[3]"
        alt=""
        src="/Waves.svg"
      />
    </section>
  );
};

export default Section11;
