import { FunctionComponent } from "react";
import FrameComponent from "./frame-component";

export type Section2Type = {
  className?: string;
};

const Section2: FunctionComponent<Section2Type> = ({ className = "" }) => {
  return (
    <main
      className={`self-stretch bg-[#420001] flex flex-col items-center py-[6.25rem] px-[0rem] box-border max-w-full lg:pt-[4.063rem] lg:pb-[4.063rem] lg:box-border mq450:pt-[2.625rem] mq450:pb-[2.625rem] mq450:box-border ${className}`}
    >
      <div className="w-full h-[45.431rem] flex flex-col items-start pt-[0rem] px-[0rem] pb-[4.181rem] box-border max-w-full mq450:pb-[1.75rem] mq450:box-border">
        <div className="flex flex-col items-start gap-[1.25rem] shrink-0 max-w-full">
          <section className="w-[90rem] flex items-start justify-center py-[0rem] pl-[1.25rem] pr-[1.562rem] box-border max-w-full text-center text-[2.5rem] text-[#fcfaf9] font-['PP_Mori']">
            <div className="flex flex-col items-center gap-[0.937rem]">
              <h1 className="m-0 relative text-[length:inherit] tracking-[0.01em] leading-[3.125rem] [text-shadow:0.1px_0_0_#fcfaf9,_0_0.1px_0_#fcfaf9,_-0.1px_0_0_#fcfaf9,_0_-0.1px_0_#fcfaf9] font-[inherit] mq450:text-[1.5rem] mq450:leading-[1.875rem]">
                <span className="font-extralight">{`Explorez des ateliers `}</span>
                <span className="font-light font-['PP_Eiko_Italic']">
                  sur mesure
                </span>
                <span className="font-extralight">
                  ,<br />
                </span>
                <span className="font-light font-['PP_Eiko_Italic']">
                  adaptés
                </span>
                <span className="font-extralight"> à tous vos événements</span>
              </h1>
              <div className="relative text-[1rem] tracking-[0.05em] leading-[1.875rem] font-extralight">
                Plongez dans des expériences œnologiques uniques, entre
                découverte, dégustation et convivialité.
                <br /> Des ateliers variés pour apprendre, partager et vivre le
                vin de manière originale, seul, entre amis ou en équipe.
              </div>
            </div>
          </section>
          <div className="w-[90rem] flex items-center justify-between gap-[1.25rem] max-w-full">
            <section className="h-[27.5rem] w-[20.938rem] flex items-center justify-between py-[1.25rem] px-[0rem] box-border max-w-full text-left text-[1.75rem] text-[#fcfaf9] font-['PP_Mori']">
              <div className="self-stretch flex-1 flex flex-col items-end justify-between gap-[1.062rem] max-w-full">
                <img
                  className="w-[20.938rem] h-[13.875rem] relative rounded-tl-none rounded-tr-[20px] rounded-br-[20px] rounded-bl-none object-cover"
                  loading="lazy"
                  alt=""
                  src="/image-1@2x.png"
                />
                <div className="h-[9.375rem] flex flex-col items-start gap-[0.312rem]">
                  <h2 className="m-0 relative text-[length:inherit] tracking-[0.01em] leading-[3.125rem] [text-shadow:0.1px_0_0_#420001,_0_0.1px_0_#420001,_-0.1px_0_0_#420001,_0_-0.1px_0_#420001] font-[inherit] mq450:text-[1.375rem] mq450:leading-[2.5rem]">
                    <span className="font-extralight">{`Découverte des `}</span>
                    <span className="font-light font-['PP_Eiko_Italic']">{`vins `}</span>
                  </h2>
                  <div className="w-[17.75rem] relative text-[1rem] tracking-[0.05em] leading-[1.875rem] font-extralight inline-block">
                    Partez à la rencontre des terroirs et des cépages
                    emblématiques à travers une sélection de vins .
                  </div>
                </div>
              </div>
            </section>
            <section className="h-[27.5rem] flex flex-col items-center justify-between py-[1.25rem] px-[0rem] box-border gap-[1.062rem] max-w-full text-left text-[1.75rem] text-[#fcfaf9] font-['PP_Mori']">
              <img
                className="w-[20.938rem] h-[13.875rem] relative rounded-[20px] object-cover"
                loading="lazy"
                alt=""
                src="/Degustations-thematiques@2x.png"
              />
              <div className="w-[20.938rem] h-[9.375rem] flex flex-col items-start gap-[0.312rem]">
                <h2 className="m-0 relative text-[length:inherit] tracking-[0.01em] leading-[3.125rem] [text-shadow:0.1px_0_0_#420001,_0_0.1px_0_#420001,_-0.1px_0_0_#420001,_0_-0.1px_0_#420001] font-[inherit] mq450:text-[1.375rem] mq450:leading-[2.5rem]">
                  <span className="font-extralight">{`Dégustations `}</span>
                  <span className="font-light font-['PP_Eiko_Italic']">
                    thématiques
                  </span>
                </h2>
                <div className="self-stretch relative text-[1rem] tracking-[0.05em] leading-[1.875rem] font-extralight">
                  Explorez des univers uniques : régions, cépages, styles de
                  vins… pour enrichir vos connaissances et affiner vos sens.
                </div>
              </div>
            </section>
            <img
              className="h-[28.75rem] w-[0.031rem] relative max-w-full overflow-hidden"
              alt=""
              src="/Vector-1.svg"
            />
            <FrameComponent
              propos="Apprenez à marier saveurs et arômes pour sublimer chaque dégustation et créer des associations gourmandes."
              image3="/Accords-mets-vins@2x.png"
            />
            <FrameComponent
              propos="Renforcez la cohésion de vos équipes grâce à une expérience conviviale, ludique et immersive autour du vin."
              proposWidth="unset"
              proposDisplay="unset"
              proposAlignSelf="stretch"
              image3="/Team-building-sensoriel@2x.png"
            />
          </div>
        </div>
        <div className="flex items-start py-[0rem] pl-[34.375rem] pr-[34.687rem] shrink-0 mq450:pl-[1.25rem] mq450:pr-[1.25rem] mq450:box-border">
          <button className="cursor-pointer [border:none] py-[1.562rem] px-[2.437rem] bg-[#fcfaf9] w-[20.938rem] rounded-[80px] flex items-center justify-between box-border shrink-0 gap-[0.625rem] hover:bg-[#e3e0e0] hover:gap-2.5">
            <div className="relative text-[1rem] tracking-[0.1em] uppercase font-['PP_Mori'] text-[#420001] text-left">
              Trouver l'atelier idéal
            </div>
          </button>
        </div>
      </div>
    </main>
  );
};

export default Section2;
