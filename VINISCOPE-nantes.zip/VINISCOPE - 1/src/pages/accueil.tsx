import { FunctionComponent } from "react";
import Header from "../components/header";
import Section11 from "../components/section11";
import Section2 from "../components/section2";
import Section31 from "../components/section31";
import CTA from "../components/c-t-a";
import Row11 from "../components/row11";
import Row21 from "../components/row21";

const Accueil: FunctionComponent = () => {
  return (
    <div className="w-full relative bg-[#fcfaf9] border-[#000] border-solid border-[1px] box-border overflow-hidden flex items-center justify-between py-[3rem] px-[0rem] leading-[normal] tracking-[normal] gap-[1.25rem]">
      <main className="h-[264.688rem] flex-1 flex flex-col items-center justify-between gap-[1.25rem] max-w-full">
        <Header />
        <section className="self-stretch h-[47.5rem] flex flex-col items-center justify-between gap-[1.25rem] text-left text-[2.5rem] text-[#420001] font-['PP_Eiko_Italic']">
          <div className="w-[83.75rem] flex items-center justify-between gap-[1.25rem]">
            <h1 className="m-0 relative text-[length:inherit] tracking-[0.01em] [text-shadow:0.1px_0_0_#420001,_0_0.1px_0_#420001,_-0.1px_0_0_#420001,_0_-0.1px_0_#420001] font-[inherit] mq450:text-[1.5rem]">
              <span className="font-light">{`L'art `}</span>
              <span className="font-extralight font-['PP_Mori']">
                {`du vin, au service `}
                <br />
                {`de la `}
              </span>
              <span className="font-light">cohésion</span>
              <span className="font-extralight font-['PP_Mori']"> !</span>
            </h1>
            <div className="w-[48rem] relative text-[1rem] tracking-[0.05em] leading-[1.875rem] font-extralight font-['PP_Mori'] text-[#323232] text-right inline-block shrink-0">
              Offrez-vous une parenthèse conviviale avec Viniscope. Nos ateliers
              vous permettent de découvrir le vin autrement : apprendre,
              déguster et partager. Pour les entreprises, nos activités de team
              building renforcent les liens tout en proposant une expérience
              originale et mémorable.
            </div>
          </div>
          <img
            className="self-stretch h-[37.5rem] max-w-full overflow-hidden shrink-0 object-cover"
            loading="lazy"
            alt=""
            src="/row-2@2x.png"
          />
        </section>
        <Section11 />
        <Section2 />
        <Section31 />
        <CTA />
        <footer className="w-[83.75rem] h-[32.625rem] flex flex-col items-center justify-between gap-[1.25rem] max-w-full text-left text-[1rem] text-[#323232] font-['PP_Mori']">
          <Row11 />
          <Row21 />
          <div className="self-stretch flex items-center justify-between gap-[1.25rem] max-w-full">
            <div className="flex items-center justify-center max-w-full">
              <div className="relative tracking-[0.1em] uppercase font-extralight">
                © 2026 Viniscope, Tout droit réservé
              </div>
            </div>
            <div className="flex items-center gap-[3rem] max-w-full mq450:gap-[1.5rem]">
              <div className="relative tracking-[0.1em] uppercase font-extralight">
                Mentions légales
              </div>
              <div className="relative tracking-[0.1em] uppercase font-extralight">
                Politique de confidentialité
              </div>
              <div className="relative tracking-[0.1em] uppercase font-extralight">
                Paramètres des cookies
              </div>
            </div>
          </div>
        </footer>
      </main>
    </div>
  );
};

export default Accueil;
